//Principio de substitucion de Liskov (LSP), las clases derivadas podran ser subsituidas por su clase base

// Clase base para vehículos
class Vehiculo {
    // Este metodo sirve para describirse que es un vehiculo
    public String describir() {
        return "Soy un vehículo";
    }
}

// Se aplica la herencia para crear mas clases de otros tipos de vehiculo como Auto
class Auto extends Vehiculo {
    // heredamos el metodo de vehiculo y este se describe segun su forma
    @Override
    public String describir() {
        return "Soy un auto";
    }
}

// Subclase de Vehiculo para bicicletas
class Bicicleta extends Vehiculo {
    // heredamos el metodo de vehiculo y este se describe segun su forma
    @Override
    public String describir() {
        return "Soy una bicicleta";
    }
}

//Nuestra clase base "Vehiculo" podria substituir en cualquiera d elos tipos 
//de vehiculo