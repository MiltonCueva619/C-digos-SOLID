// Principio de responsabilidad unica (SRP): una clase debe cumplir su funcion especifica si tiene mas de una se 
// separan para crear otra clase

//Creamos una clase de una corporativa de ventas de una empresa 
class EjecutivoVenta {
    public String capacidad;
    public String cliente;
    public int redNumero;
    public String codigoProblema;
   
//obviamente la o el ejecutivo de ventas tendra la funcion de vender mas capacidad a un cliente     
    public void venderFibra(){
        System.out.println("Se vende la capacidad de " + capacidad + " al cliente" + cliente);
    }
    
// Pero reparar la red a un cliente ya es otra tarea que le compete a otro tipo de profesional     
    public void repararRed(){
        System.out.println("Arreglando la red " + redNumero + "que presenta el codigo de error" + codigoProblema);
    }
} 
//este codigo no cumple con el principio de responsabilidad unica

//Cual es la solucion ? Separar las clases y crear una nueva clase para nuestro personal de soporte tecnico    
//Codigo corregido
class SoporteTecnico {
    public String nombreTecnico;
    public int redNumero;
    public String codigoProblema;  
    
    public void repararRed(){
       System.out.println(nombreTecnico + "personal capacitado, esta reparando la red " + redNumero + "que presenta el codigo de error" + codigoProblema);
    } 
}
   
//Ahora la clase del ejecutivo de ventas solamente con la funcion de vender 
class EjecutivoVenta {
    public String capacidad;
    public String cliente;
   
//obviamente la o el vendedor corporativo tendra la funcion de vender mas capacidad a un cliente     
    public void venderFibra(){
        System.out.println("Se vende la capacidad de " + capacidad + " al cliente" + cliente);
    } 
}

    
    
