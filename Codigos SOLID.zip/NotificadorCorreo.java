//Principio de Inversion de Dependencia (DIP): Los modulos de alto nivel no deben depender de los de bajo nivel y los 
//de bajo nivel tampoco deben depender de los de alto nivel, los dos deben depender de las abstraccciones, asi como 
//las abstracciones no deben depender de los detalles sino los detalles de las abstracciones


// Interfaz que representa un notificador
interface Notificador {
    void notificar(String mensaje);
}

// Implementación concreta de notificador que envía correos electrónicos
class NotificadorCorreo implements Notificador {
    @Override
    public void notificar(String mensaje) {
        // Enviamos la notificacion
        System.out.println("Enviando correo electrónico: " + mensaje);
    }
}

// Clase Usuario que depende de la abstracción Notificador y no depende de ningun modulo
class Usuario {
    public Notificador notificador;

    // Constructor que acepta un notificador
    public Usuario(Notificador notificador) {
        this.notificador = notificador;
    }

    // Método para enviar una notificación utilizando el notificador
    public void enviarNotificacion(String mensaje) {
        notificador.notificar(mensaje);
    }
}