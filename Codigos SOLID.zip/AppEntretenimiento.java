//Principio de la segregacion de la interfaz (ISP): no debemos obligar al ususario a depender de interfaces 
//que no utilice o que no se use.
//Imaginemonos que tenemos una aplicacion de entretenimiento que tiene varias opciones como peliculas, musica, podcast 
//y videojuegos, el usuario la mayoria de veces sabe lo que quiere hacer y va directamente a la opcion de su preferencia
//si el usuario quiere ver peliculas no debemos mostrarle un menu donde vea opciones de canciones, podcast o los videojuegos
//disponibles aparte de las peliculas, eso estaria mal, entonces el principio ISP nos dice que hagamos diferentes interfaces
//una separada de la otra y que contenga cada opcion.

//Interfaz para la opcion de peliculas
interface ReproductorPeliculas {
    void reproducirPelicula();
}
//Interfaz para las canciones
interface ReproductorMusica {
    void reproducirMusica();
}
//Interfaz para los podcast
interface ReproductorPodcast {
    void reproducirPodcast();
}    
//Interfaz para los videojuegos
interface ReproductorVideojuegos {
    void jugarVideojuego();
}    

//Ahora si el usuario si quiere ver peliculas escogera esta opcion y vera solamente el interfaz de peliculas
class VerPelicula implements ReproductorPeliculas{
    @Override
    public void reproducirPelicula(){
        System.out.println("La pelicula se esta reproduciendo");
    }
}
//Lo mismo si quiere escuchar musica
class EscucharMusica implements ReproductorMusica{
    @Override
    public void reproducirMusica(){
        System.out.println("Reproduciendo musica");
    }
}
//Si escoge podcaste pues tendra a su dispoicion el interfaz de podcast
class EscucharPodcast implements ReproductorPodcast{
    @Override
    public void reproducirPodcast(){
        System.out.println("Reproduciendo un podcast");
    }
}
//Finalmente si desea jugar videojuegos igual tendra esta opcion independiente
class Jugar implements ReproductorVideojuegos{
    @Override
    public void jugarVideojuego(){
        System.out.println("Estas jugando");
    }
}

