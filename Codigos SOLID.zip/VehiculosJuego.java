// OCP(Principio de abierto cerrado): las entidades de sofwtare en nuestro codigo deben estar abiertos para la expansion pero cerrados
// para la modificacion, se debe poder agregar nuevas funciones sin tener que cambiar el codigo principal o codigo fuente

//En este caso tenemos una parte del codigo de un juego exactamente el codigo de los vehiculos del juego, para que los jugadores
//siempre esten emocionados debemos agregar frecuentemente nuevos vehiculos y de todo tipo
public class VehiculosJuego {
    public String nombre;
    public int velocidad; 
    public int vida;
    public int numeroPasajeros;
   
//Creamos el cosntructor de nuestra clase 
    public VehiculosJuego(String nombre, int velocidad, int vida, int numeroPasajeros){
       this.nombre = nombre;
       this.velocidad = velocidad;
       this.vida = vida;
       this.numeroPasajeros = numeroPasajeros;
   }  
 
//como todo vehiculo podra moverse
    public void moverse (int velocidad, int vida){
        System.out.println("Te estas moviendo a" + velocidad + "km/h, y tiene una vida de " + vida);
}  
//Estaria mal continuar escribiendo codigo para en esta misma clase generar tipos de vehiculos, la solucion sera
//apoyarnos en la herencia y de esta clase principal


//Ahora apoyandonos de la herencia vamos a crear clases que herenden de la clase principal "VehiculosJuego", crearemos otros
//tipos de vehiculo, en este caso crearemos los vehiculos terrestres
 public class VehiculoTerrestre extends VehiculosJuego {
     public int numeroLlantas;
//El metodo constructor que nos ayudara a construir diferentes vehiculos terrestres    
     public VehiculoTerrestre(String nombre, int velocidad, int vida,int numeroPasajeros, int numeroLlantas){
        super(nombre, velocidad, vida,numeroPasajeros);
        this.numeroLlantas = numeroLlantas;
}
//Personalizaremos la forma en que se mueve
     public void moversePorTierra (){
        System.out.println("Estas moviendote en un" + nombre +" con capacidad para " + numeroPasajeros + "pasajeros, tu vehiculo usa" + numeroLlantas);
     }
 }
 
 //Seguimos aplicando el principio y vemos que es facil la expansion y actualizacion de los vehiculos del juego 
 //asi que ahora creamos la clase para los vehiculos marinos
 public class VehiculoMarino extends VehiculosJuego {
     public int cañasDePescar;
 //Metodo constructor para crear mas tipos de vehiculos marinos con los atributos heradados y un atributo propio  
     public VehiculoMarino(String nombre, int velocidad, int vida, int numeroPasajeros, int cañasDePescar){
         super(nombre, velocidad, vida, numeroPasajeros);
         this.cañasDePescar = cañasDePescar;        
     }
//Igual personalizamos un poco el movimiento   
     public void moversePorAgua(){
         System.out.println("Te estas moviendo por el agua en un " + nombre + "a una velocidad de " + velocidad + "km/h, pueden ingresar hasta" + numeroPasajeros);  
     }
 }
}
//ASi que podemos seguir expandiendo los tipos de vehiculos que tenemos en nuestro juego apoyandonos del Principio de abierto cerrado
